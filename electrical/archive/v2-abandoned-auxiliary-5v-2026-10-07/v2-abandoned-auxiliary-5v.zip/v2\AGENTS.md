# V2 working instructions

Read `../AGENTS.md` and `../../AGENT/KONNECT_WORKFLOW.md` first.

- V2 work must not change V1 unless explicitly requested.
- Copied hardware retains V1's 70 V limitation until protection and sensing
  are redesigned and verified. Architecture targets are not capabilities.
- Read `docs/OUTPUT_RECEIVER_STUDY.md` before selecting output limits.
  The 400 W architecture target is input power.
- Distinguish station supply profiles from battery charging algorithms.
  Do not infer chemistry from terminal voltage.
- Use this revision's `kicad/libraries/`. Shared references remain in
  `../components/`, measurements in `../measurements/` with revision identified.
- Inherited V1 rules in `.konnect/project.json` describe the copied circuit.
  Update through Konnect as blocks are redesigned; they do not freeze V2 parts.
- Do not infer purchasing or fabrication readiness from the starting copy.

## Schematic presentation

Follow the user's V1 readability corrections, especially commit `583232d`
(local label links replaced with connected circuits) and `aefcb01` (grouping
and annotation placement). The saved V1 auxiliary supply is the visual reference.

- Draw continuous wires within a functional block. Move nearby supporting
  components into that block instead of joining isolated pieces with repeated
  net labels.
- Show series paths, feedback dividers, enable/reset networks and local bypass
  capacitors explicitly. Prefer left-to-right signal/power flow and clear ground
  returns where the symbol pin arrangement allows it.
- Keep labels to name meaningful nodes, cross-sheet connections, shared rails,
  and connections whose wires would genuinely reduce clarity. A named signal
  is not, by itself, a reason to replace its local wire with matching labels.
- Keep references, values and concise safety notes readable and clear of wires,
  symbols and other text. Preserve provisional-design warnings.
- For presentation-only changes, compare saved before/after XML net names and
  pin endpoint sets plus component inventory/fields; run hierarchy ERC and
  inspect rendered sheets. Do not change circuitry, part selection or BOM cost.
