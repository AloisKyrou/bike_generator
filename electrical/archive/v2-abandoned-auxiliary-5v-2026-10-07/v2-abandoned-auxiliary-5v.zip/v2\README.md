# Controller V2 development

Active selection (6 October 2026): **BQ25756**, with **55 V normal input/output
working ceilings**, supersedes the earlier 80 V / roughly 60 V comparisons below.
Follow the [overall BOM/cost tracker](bom/README.md) for current inventory and
unfinished-block allowances. One receiver output; no internal dump circuitry.
These are design decisions, not verified hardware ratings.

Status: **LV2 schematic checkpoint; main power and safety integration unfinished,
not build-ready**.

The active MCU sheet uses ESP32-C3-MINI-1-N4X with reset/boot, native USB and
external PWM/ready logic. The new LV circuit includes USB/AUX selection,
BQ24074 backup-cell charging/power path, TPS63031 3.3 V regulation, USB-C and
data-line ESD. JP21 is an interim service enable, not automatic wake.
JP20 leaves charging disabled until a protected cell and NTC are qualified.
J20 is a test header, not an external 3.3 V input. USB fault containment and
the main converter remain unfinished. See the
[LV2 implementation report](docs/SCHEMATIC_LV2_PROGRESS_2026-10-06.md) and
[current review PDF](kicad/exports/review-presentation-2026-10-06/controller-v2-presentation.pdf).
The 6 October presentation pass follows the V1 corrections in `583232d` and
`aefcb01`: direct local wiring, grouped supporting parts and fewer repeated
labels on the MCU/LV sheets. All 106 component records and 90 nets are unchanged;
48 targeted assertions and hierarchy ERC pass under the existing settings.
The BOM is unchanged. See the [presentation report](docs/SCHEMATIC_PRESENTATION_2026-10-06.md)
for before/after counts and verification; conventions are recorded in [AGENTS.md](AGENTS.md).
The [first increment report](docs/SCHEMATIC_PROGRESS_2026-10-06.md) is historical.
V1 and the copied V2 PCB remain unchanged; no firmware work was performed.

Latest research scope (2026-10-05): the user wants broad second-hand generator
and receiver coverage, including e-bike batteries and an own-motor trainer.
Start with the [compatibility decision pack](docs/compatibility/README.md).
Its broad-use recommendation reopens buck-boost / approximately 60 V output;
the earlier 12-32 V buck recommendation applied to the narrower current setup.
The earlier study does not select components or implement circuitry.

User direction (2026-10-06): support an integrated-converter assembly and an
external-converter assembly with the internal main stage omitted. External buck,
boost and buck-boost modules need qualified hardware/control profiles; software
cannot make an arbitrary module compatible. **No internal dump load or optional
dump-stage footprints**: external-load control belongs to the generic GPIO
interface only. See the dated decisions in the
[architecture specification](docs/CONTROLLER_V2_INTEGRATED_SPEC.md).
These remain design requirements, except for the first unqualified logic-level
PWM/ready interface. No external accessory power stage is on the mainboard.

Fablab/accessibility requirement: design one full-scope reference with documented
lower-cost assembly variants. A qualified DC generator can use a protected DC
entry with the AC rectifier omitted; this is independent of internal/external
converter selection. Publish exact fitted/DNP BOMs, required links, limitations,
configuration and tests for each supported build. Keep only a few tested prebuilt
versions initially; the full-feature prebuilt offering can follow later. The
reference scope is not a promise of universal compatibility or an internal dump.

User-confirmed operating baseline (2026-10-05): the scooter generator produces
approximately 36 V and the existing buck supplies 24 V to the AC50S. Boost is
unnecessary for this working setup. V2 starts from that buck-only use case;
buck-boost research concerns optional broader source/receiver compatibility,
not a missing function in the current installation. The final V2 scope remains
open; this confirmation is not a full cadence/thermal qualification.

Open [bike-generator-controller-v2.kicad_pro](kicad/bike-generator-controller-v2/bike-generator-controller-v2.kicad_pro).

- [Integrated architecture](docs/CONTROLLER_V2_INTEGRATED_SPEC.md).
- [Output receiver study](docs/OUTPUT_RECEIVER_STUDY.md).
- [Existing converter reference designs](docs/POWER_CONVERTER_REFERENCE_STUDY.md).
- [BQ25756 implementation calculations and gates](docs/BQ25756_IMPLEMENTATION_NOTES.md).
- [USB and logic-power fault cases](docs/USB_AND_LV_FAULT_REVIEW.md).
- [Buck-only effort, 30 V output and pedal feel](docs/BUCK_ONLY_AND_PEDAL_FEEL.md).
- [Copy provenance and verification](docs/BASELINE_AND_MIGRATION.md).
- [BOM status](bom/README.md).
- [Component candidates and pilot cost](bom/CANDIDATES_AND_COST.md).
- [Shared manufacturer references](../components/README.md).
- [Shared measurements](../measurements/README.md).

The project and libraries were copied from V1 on 2026-10-05. Konnect renamed
the project and updated hierarchical project-instance references. The first
schematic increments change the MCU and low-voltage subsystems, while the inherited power path,
auxiliary converter, sensing and CC/CV control remain the V1 baseline. Routing
is still V1 and does not match the new schematic. The old 80 V target is
superseded. Integrated main conversion, qualified USB protection and automatic
soft power are not implemented.

Each revision owns its libraries. The inherited `INA228_SENSE` name and V1
silkscreen remain; U1 is INA238. A module's own V2 suffix is not our PCB revision.

Next tasks: resolve BQ model permission/provenance, CV range selection, wake and
USB fault protection; define independent output protection and converter
interfaces. Select representative donor motors and one documented e-bike
battery/charger. Measure generator voltage versus cadence and receiver
acceptance before finalizing the operating envelope.
No V2 manufacturing or purchasing release exists.
