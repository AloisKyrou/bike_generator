﻿# V2 overall cost dashboard

Generated from a saved schematic XML export; NOT a purchasing or fabrication release.
EUR per board, excluding VAT and delivery. Column 10 means per board in a ten-board batch.

Export: after.xml; SHA-256: 3B4D5CD4DBDE885BDD1973FB82A49F35181CFB558F8D9A9A4215AE54410B427D
Components exported: 106. Fitted entries without price: 9.

| Block | Drawn parts, 1 board | Complete-block budget, 1 board | Complete-block budget, 10 boards |
|---|---:|---:|---:|
| AC bridge and AC-entry connector | 10.00-14.00 | 10.00-14.00 | 7.00-10.50 |
| Input protection and DC power connectors | 9.67-10.67 | 10.00-18.00 | 8.29-14.00 |
| Input telemetry and Kelvin shunt | 5.03-8.10 | 5.03-8.10 | 4.89-7.40 |
| Complete HV-to-5V auxiliary branch | 14.73-19.05 | 14.73-19.05 | 13.36-17.04 |
| ESP32 module and module service circuitry | 3.28-5.90 | 4.00-7.00 | 3.50-6.00 |
| USB battery charger 3V3 regulation and wake | 7.97-14.78 | 12.00-21.00 | 9.00-17.00 |
| CV selection external converter control and GPIO | 3.14-6.18 | 6.00-12.00 | 4.50-9.00 |
| BQ25756 main converter stage | 0.00-0.00 | 32.00-52.00 | 25.00-41.00 |
| Receiver disconnect protection sensing and connector | 0.00-0.00 | 8.00-18.00 | 6.00-14.00 |
| Protected logic cell and suitable temperature sensor | 0.00-0.00 | 5.00-10.00 | 4.00-8.00 |
| Converter and rectifier cooling hardware | 0.00-0.00 | 10.00-25.00 | 8.00-20.00 |
| Enclosure harness mating plugs and cadence sensor | 0.00-0.00 | 20.00-45.00 | 15.00-35.00 |
| Bare PCB allocation per unit | 0.00-0.00 | 20.00-50.00 | 8.00-20.00 |
| Assembly programming and routine test per unit | 0.00-0.00 | 40.00-100.00 | 20.00-45.00 |

board_components : 1 board 101.76-169.15; 10-board batch per board 81.54-135.94 EUR.
offboard_hardware : 1 board 35.00-80.00; 10-board batch per board 27.00-63.00 EUR.
manufacturing : 1 board 60.00-150.00; 10-board batch per board 28.00-65.00 EUR.
ALL : 1 board 196.76-399.15; 10-board batch per board 136.54-263.94 EUR.

Do not add drawn costs to complete-block budgets: they overlap. Projected values are the larger of the complete-block allowance and drawn priced subtotal. Unpriced components are reported, not valued at zero; a block budget is not proof that its missing parts fit.

Scope: full AC-capable integrated-converter reference, one receiver, no internal dump. MAIN and RECTIFIER budgets can be omitted only for qualified variants; an external converter and its adapter/cooling are additional, not free. Remaining common protections stay.

Unknowns: high-voltage USB fault containment, independent output protection, CV selection accuracy, magnetics and thermal qualification can increase this estimate. Prices are observations/allowances, not reserved inventory. Read README.md and project-budget.csv for assumptions.

Excluded: bicycle, donor generator, trainer mechanics/guards, main receiver battery, special OEM chargers/adapters, development labor, failed prototypes, compliance/certification, warranty, shipping, VAT and commercial margin. No selling price is inferred.
