# V2 BOM status

## Overall tracker (active, 6 October 2026)

Start with [COST_DASHBOARD.md](COST_DASHBOARD.md) for the overall estimate and
[controller-v2-overall-bom.csv](controller-v2-overall-bom.csv) for every component
in the last exported schematic. [controller-v2-cost-blocks.csv](controller-v2-cost-blocks.csv)
shows the drawn subtotal, complete-block budget and remaining allowance per block.
These are living design records, **not a released ordering BOM**.

The user selected **BQ25756 and a 55 V working ceiling**. The current budget
includes one receiver output, USB/backup/wake, and the retained auxiliary supply.
It excludes all internal dump circuitry. Reference MOSFETs and magnetics are
cost comparators, not automatically approved selections or continuous ratings.

Cost method:

- [pricebook.csv](pricebook.csv) distinguishes dated distributor observations,
  historical estimates and engineering allowances. An exact MPN price takes
  precedence over a generic passive/header allowance. Manufacturer constraints
  are matched too: an ST part is not priced as a same-named unrelated vendor's
  part. Stock is not reserved.
- [project-budget.csv](project-budget.csv) is the **complete cost of each block**,
  including functions not yet drawn. Never add it to the drawn-component total.
  The dashboard takes the larger of this allowance and the priced drawn subtotal.
  A reserve is arithmetic headroom, not a fully specified missing-parts BOM.
- Unknown prices remain blank and are counted explicitly. A zero is used only
  for PCB copper features such as testpads/solder jumpers, not unknown parts.
- Ten-board costs are per board, not the batch total. Exact known quantity breaks
  are used conservatively; no guessed discount on inherited price observations.
- These estimates exclude VAT, delivery and engineering. PCB, cooling, cell,
  enclosure/harness and assembly appear separately, so DIY labor is not hidden
  inside the component cost. The dashboard is not a proposed retail price.

Regenerate only from a fresh hierarchy-aware KiCad XML export:

```powershell
./electrical/v2/bom/update-cost-tracker.ps1 -Netlist <path-to-exported-controller-v2.xml>
```

The script reads structured XML/CSV and writes only BOM/report files. It never
edits KiCad files. A new sheet name or component without a price is deliberately
visible rather than silently omitted. Add exact prices and review block budgets
as the schematic develops. Do not remove mandatory safety budget to meet a target.

Variant cost interpretation: the RECTIFIER block is AC-specific; MAIN is specific
to the integrated converter. Other functions/protections remain common. An
external-converter board subtotal excludes the external converter purchase,
adapter and any additional cooling; that subtotal is not a complete system cost.
Exact reference-level variant/DNP lists remain pending design qualification.

## Cost priorities

1. Main converter: current complete-block allowance is EUR32-52 one-off.
   The EVM-comparator BQ controller, four SIR680LDP FETs and one main inductor
   alone total EUR23.79 at the observed one-piece prices. Power capacitors,
   shunts, filtering and gate/support parts remain additional. Compare FET
   switching/conduction losses and cooling together before chasing unit price.
2. Assembly and PCB: separate from component BOM. Fablab self-assembly can avoid
   paid assembly charges, but not the required inspection/testing or package
   difficulty. No two-layer/cheap-copper assumption is approved for the new stage.
3. Qualified DC variant: omitting the AC bridge and its entry connector removes
   roughly EUR10-14 of the current one-off block estimate. Required polarity,
   fault and current protection remain; any shared cooling remains too.
4. Fuses: the inherited main fuse is EUR5.92 and auxiliary fuse allowance is
   EUR2.80-3.20. These deserve a serviceability/cost comparison, not automatic
   replacement by a 32 V automotive blade fuse in a 55 V design. DC interrupting
   rating, fault source and protection coordination must be proven.
5. Logic supply: TPS2116 is the economical regulated-5 V selector candidate
   (EUR0.92 observation) instead of TPS2121 (EUR2.14). The SRN4018 logic inductor
   is EUR0.35. These choices do not eliminate the unfinished fault-containment
   circuitry. Do not duplicate DAC and digipot hardware by default for CV control.

These are optimization priorities, not approved substitutions or a complete
order. Source/date details live in the pricebook. The overall estimate includes
unimplemented functions explicitly, so a cheap partial circuit is not mistaken
for the final controller cost.

No V2 components are approved for purchasing. The LV2 checkpoint has 106
components, including the ESP32 module and the new low-voltage/USB circuit;
the main converter remains an allowance, not a drawn circuit. Nine generic
connectors/jumpers currently lack physical selections and prices. The
[V1 BOM](../../v1/bom/controller-v1-current.csv) records
the earlier inventory, not the current V2 schematic or a V2 order list. See the
[current schematic progress report](../docs/SCHEMATIC_LV2_PROGRESS_2026-10-06.md).

The [candidate and cost study](CANDIDATES_AND_COST.md), updated 2026-10-06, compares
main converter and support components, with EUR price observations and separate
planning allowances for 1, 10 and 50 units. It is not an orderable BOM.

Scope update 2026-10-06: no internal dump stage, including optional footprints;
external-load GPIO control only. Also plan separate integrated-converter and
external-converter assembly BOMs. `budget-blocks-2026-10-05.csv` remains historical
and includes dump allowances no longer in the base product; the study records the
excluded rows without presenting a new complete quote.

For fablab accessibility, plan assembly BOMs along two independent axes:
AC rectifier fitted / protected DC entry with rectifier omitted, and integrated
converter fitted / qualified external converter. These combinations are design
intent, not validated build recipes. Each published BOM must list exact fitted
and DNP references, mandatory links/adapters, shared protections, cooling,
software profile and acceptance tests. Do not remove an entire protection block
just because its rectifier or converter is omitted. DIY recipes can cover more
combinations than the small number of prebuilt products offered initially.

Select power components after the [output study](../docs/OUTPUT_RECEIVER_STUDY.md)
and generator measurements establish electrical limits and cooling requirements.
