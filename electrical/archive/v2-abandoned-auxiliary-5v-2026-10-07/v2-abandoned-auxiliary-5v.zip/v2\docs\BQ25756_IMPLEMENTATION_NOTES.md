# BQ25756 implementation notes

6 October 2026. Engineering work for the selected controller and 55 V normal
input/output envelope. **No main-stage circuit is qualified by these notes.**
The [overall BOM](../bom/README.md) carries the missing circuitry explicitly.

## Current and magnetics

The provisional 15 A input / 10 A output / 400 W input limits are independent.
At an assumed 90% converter efficiency:

`Pout = min(0.90 * 400 W, 0.90 * Vin * 15 A, Vout * 10 A)`.

This is power at the converter terminals, after rectifier/wiring losses. It is
not rider mechanical power, a measured efficiency, or a continuous rating.
Receiver acceptance can reduce power further. The auxiliary branch also consumes
generator power; do not include it in main-stage current telemetry unnoticed.

[Reproducible calculation](calculations/power-envelope.mjs) and
[result table](calculations/power-envelope.csv) cover representative pairings.
The script checks all 8,281 half-volt pairs from 10 to 55 V against the limits.
Ten volts is a modelling boundary, not a new guaranteed startup specification.

TI's EVM uses a 10 uH IHLP6767GZER100M01 inductor. Its nameplate current is not
enough to qualify our 15 A-input boost corners. Away from transition, a first
ideal CCM ripple estimate is:

`Delta_IL = Vlow * (1 - Vlow/Vhigh) / (L * fsw)`.

At 250 kHz and 10 uH, the largest ideal ripple in the 55 V envelope is 5.5 A
peak-to-peak (27.5 V / 55 V). At 12 -> 54.6 V, a 15 A average input means roughly
16.9 A inductor peak. With an illustrative 6.4 uH effective inductance, that
becomes about 17.9 A. The 6.4 uH case is sensitivity, not a measured part bound.
Check saturation curves, temperature rise, tolerance, DC bias, current-limit
tolerance and controller transition timing before choosing an inductor.
The script uses max(Iin,Iout) as a conservative first DC-current estimate;
it does not model four-switch transition or startup/short-circuit waveforms.

An input 2 mOhm shunt dissipates 0.45 W at 15 A; 5 mOhm dissipates 1.125 W.
A 5 mOhm output shunt dissipates 0.50 W at 10 A. These are I-squared-R losses,
before tolerance, overload and thermal derating. The inherited 2 mOhm INA238
shunt cannot simply replace BQ's specified 5 mOhm battery shunt.

## Use the existing auxiliary intelligently

The BQ's gate drivers can use its internal REGN regulator or an external supply.
TI requires the external DRV_SUP bias to disappear when conversion is disabled;
an always-on wire from AUX_5V is therefore not the proposed connection.

Candidate: use the existing efficient LM5164 5 V rail through a default-off,
properly sequenced local bias switch. This can avoid a separate gate-bias buck
and reduce heat inside the BQ. Example only: four switching gates at 30 nC each
and 250 kHz need about 30 mA average. A 55-to-5 V internal linear supply would
lose about 1.5 W in that example, versus about 0.15 W delivered at 5 V by the
external source, plus its conversion/switch losses. Real charge depends on
voltage and mode; verify the datasheet's at-least-50 mA external-source guidance,
decoupling, peak currents and worst-case low AUX voltage.

Do not power DRV_SUP from USB merely because USB owns the logic rail. Preserve
the distinction between upstream generator AUX_5V and selected LV_SYS power.
Use FETs with on-resistance specified at the actual minimum drive voltage;
a 10 V-only Rds(on) rating is not evidence for reliable 5 V gate drive.

## Wide CV setting is still a real design block

BQ's I2C target is 1.504-1.566 V in 2 mV increments, around 1.536 V. The external
divider determines the output-voltage range. It is not a 0-55 V I2C DAC.

The inherited MCP42100 is not rejected just because it is old, but neither is
it accepted directly into the feedback divider. Its archived 100 kohm datasheet
specifies **70-130 kohm at 25 C**, up to 250 ohm wiper resistance at 2.7 V,
8-bit steps and terminals restricted to its supply rails. Its reset code is
midscale; shutdown connects the wiper to B and opens A. These states must be
designed, not treated as equivalent to converter off.

Illustrative bottom-leg rheostat: 499 kohm top and 14.3 kohm plus 0-100 kohm
bottom gives roughly 55.1 to 8.2 V at nominal 1.536 V, ignoring wiper/FBG errors.
Near the high end, one ideal pot step changes the setpoint by about 1.4 V.
BQ fine trim might bridge this quantization, but not automatically its error,
temperature, startup and failure cases.

More importantly, a high battery can be present while a low-voltage profile is
selected. In that example, 55 V applied with a 114.3 kohm lower leg places about
10.25 V on FB and potentially the low-voltage pot, even before conversion runs.
Returning through BQ's FBG also needs explicit off-state analysis: FBG disconnects
when the input is absent/outside its window. Do not assume FB-side circuitry is
always at 1.536 V or that a disabled converter isolates its battery terminal.

Paths worth comparing next:

[TI's response on wide output selection](https://e2e.ti.com/support/power-management-group/power-management/f/power-management-forum/1371530/bq25756-controlling-output-current-and-voltage-of-the-charger-controller-chip)
explicitly suggests a digital potentiometer or FET-switched divider for BQ25756.
It does not supply a qualified circuit for our voltage range or MCP42100.
The same response mentions BQ25758 as a wide-programmable DC/DC alternative,
but without the charger's precharge/termination functions. **No substitution is
made:** BQ25756 remains the user's selected controller. Keep that alternative
as a decision to discuss only if the external CV circuit becomes disproportionate;
do not silently trade hardware cost for new battery-safety firmware obligations.

| Approach | Benefit | Gate before drawing as qualified circuitry |
|---|---|---|
| Fixed precision divider for a known bench receiver | Cheapest and easy to measure | Explicit fixed-voltage prototype only; does not satisfy automatic broad-profile setup |
| Switched precision resistor ranges plus BQ fine trim | Keeps precision in resistors; can cover common profiles | Switch leakage/on-resistance, all-off default, attached-battery voltage, GPIO/I2C budget and independent limits |
| Buffered DAC/current injection | Broad software selection; potentially fewer range switches | Startup/power-off clamp behavior, reference/error budget, stability and independent OVP |
| Shared MCP42100 with protected analog conditioning | Reuses external-module controls | Prove a genuine useful shared circuit and complete fault/error budget; extra conditioning may erase savings |

No double DAC-plus-digipot assumption is in the overall budget. Do not replace
a model gate with an unchecked direct connection simply to fill the schematic.

### Do not accidentally change the charging thresholds

An offset-injection DAC is not equivalent to changing the divider ratio.
The BQ uses FB not only for CV, but also for precharge transition, recharge and
battery OVP. For example, suppose an ideal injection circuit gives
`Vout = K * Vfb - G * Vdac`, with `K * 1.536 V = 55 V`.
At a 14.4 V target, its default 66.7% precharge threshold would map to
`14.4 - (1 - 0.667) * 55 = -3.915 V`, rather than about 9.6 V.
Its nominal 104% OVP would map to 16.6 V, rather than about 15.0 V.
These are algebraic screening examples, not proposed component values.
The raw-SRN trickle threshold is separate; do not assume every threshold uses FB.

Thus DAC injection requires re-deriving every relevant threshold and proving
that the available register settings can represent the intended battery profile.
It is not currently the preferred simple universal-charger path. A genuine
variable divider ratio preserves the proportional thresholds more naturally.
Neither approach replaces an independent receiver-appropriate protection path.

A resistor-bank study can use a fixed top resistor and binary-weighted
conductance to ground in the bottom leg. Six ideal range bits spanning 12-55 V
have about 0.68 V coarse steps; the BQ's roughly 4% total fine-adjustment span
cannot bridge those steps at the low-voltage end. Seven bits reduce the ideal
step to about 0.34 V and merit calculation, but require seven switches and an
I/O budget. Precision, leakage, switch resistance, code transitions and attached
battery states must still be checked. Returning the bank directly to ground
instead of FBG changes off-state battery drain and needs explicit review; a
bank of ground-referenced MOSFET gates cannot casually float its sources up
with FBG without checking gate-source absolute limits.

### The 55 V ceiling needs tolerance headroom

55 V is an envelope limit, not permission to command a nominal 55 V while
ignoring positive regulation error, divider tolerance, FBG resistance or ripple.
A 13S lithium target of 54.6 V leaves only 0.4 V (about 0.73%) to that ceiling.
BQ's specified feedback accuracy alone is +/-0.5% at 0-85 C and +/-0.7% over
the full rated temperature range. Two independent 0.1% divider resistors add
roughly 0.2% worst-case ratio error before other terms. That already consumes
or exceeds the headroom in some corners. Include setpoint guard-banding,
calibration residual and the permitted receiver charging voltage in the final
error budget. A pack that can be externally charged above 55 V is still not
qualified merely by choosing a lower charging target here.

## Independent protection

CE, ICHG-pin limiting and ILIM_HIZ-pin limiting can each be disabled by register
settings. The power-on current registers default high. Those resistor limits
are valuable defaults, but **not independent protection against firmware faults**.
The watchdog/reset behavior, MPPT-disabled policy and reverse-disabled policy
need explicit review. A hardware receiver disconnect and appropriate voltage,
current and thermal limits remain separate design work.

The inherited SMCJ70A does not impose 55 V. A fuse cannot control sustained
generator overvoltage. With no dump, interruption can unload the generator and
raise its voltage: qualify maximum open-circuit/overspeed voltage and the entire
input path, not just the main controller while loaded.

## Evidence

- [Archived BQ25756 datasheet and EVM documents](../../components/ti-bq25756/README.md):
  SLUSEN5A pins and sections 6.3.3.2, 6.3.5.1.1.1, register 0x00 and application
  divider equations; SLUUCT7D EVM BOM. Authoritative for controller requirements.
- [TI MOSFET selection guide](https://www.ti.com/lit/pdf/sluaax9): design-calculator
  and loss-analysis method, not a project efficiency guarantee.
- [Archived Microchip MCP42100 datasheet](../../components/dfr0520-mcp42100/microchip-mcp41xxx-42xxx-11195c.pdf),
  DS11195C page 4 and reset/shutdown sections. Calculations above are project
  screening examples, not copied application circuits.
