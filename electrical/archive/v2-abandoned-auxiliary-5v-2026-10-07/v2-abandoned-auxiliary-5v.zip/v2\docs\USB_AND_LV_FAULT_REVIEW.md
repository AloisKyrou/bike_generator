# USB and logic-power fault review

6 October 2026. Review of the [LV2 schematic checkpoint](SCHEMATIC_LV2_PROGRESS_2026-10-06.md).
**Open design work, not permission to connect a PC to the generator-powered board.**

## What is already drawn

TPS2116 selects USB or the generator-derived 5 V rail, BQ24074 manages the
backup cell/system power, and TPS63031 produces 3.3 V. USBLC6-2SC6 suppresses
data-line ESD. These are different functions; neither the mux nor ESD array is
a galvanic isolator or a demonstrated sustained high-voltage fault barrier.

## Cases to close before a usable prototype

| Case | Current circuit / risk | Required evidence or change |
|---|---|---|
| USB only, no backup cell | Charger input stays in 100 mA mode; available system power is limited | Cold boot/programming load measurement; radio operation must not be assumed |
| USB + AUX, both valid | USB priority, separate power paths | Reverse-current and hot-plug tests across source tolerances |
| USB weak but still above mux threshold | Mux can retain USB below BQ useful input voltage; cell may discharge despite AUX being present | Brownout/failover test; consider a more precise source-valid detector if necessary |
| AUX/cell on, USB host off | ESP USB pull-up or driven data can reach the connector-side ESD steering network | Prove no unwanted data-to-VBUS/host injection; VBUS detection and/or powered-off-protected data disconnect may be needed |
| USB on, MCU rail off | Host data may reach an unpowered MCU | Check pin injection limits, PHY state and disconnect behavior |
| AUX regulator high-side fault | 55 V bus can reach devices with 5.5 V operating limits | Independent upstream fault containment, with worst-case transient and fault-energy analysis |
| Incorrect USB source / CC short to VBUS | Rd resistors and data ESD do not prove CC/VBUS fault protection | Define supported 5 V sources and connector fault envelope; choose/test protection accordingly |
| Cell reversed / unknown chemistry / no NTC | Current drawing has a generic connector and charging disabled | Keyed connector, protected 4.2 V 1S cell, suitable NTC, polarity and charging qualification |
| Empty cell and radio current pulse | Switch-current rating is not output-current guarantee | Cell cutoff, effective capacitance, startup and RF load-step tests |
| Backup-only soft-off | JP21 is a service jumper, not a power-button controller | Implement wake, grace period, forced-off and leakage requirements |

The data-to-VBUS risk above is a **circuit inference**, not a measured failure:
ST's functional diagram contains steering diodes from I/O to VBUS, while the
MCU can remain powered independently. Reverse blocking in U5 only addresses
its power paths; it cannot establish isolation of the separate USB data paths.

## Economical candidates, not selected additions

- An adjustable-OVP high-voltage eFuse **before the AUX input of the mux** merits
  study. TI TPS2660 operates from 4.2-60 V with integrated back-to-back FETs;
  TPS2662 operates from 4.5-60 V but has higher on-resistance. Select the exact
  adjustable-cutoff variant, not a similarly named fixed high-voltage-clamp part.
  Neither automatically covers generator overspeed above its ratings. Check
  leakage, voltage drop at 606 mA, threshold tolerance, cutoff response, output
  overshoot and startup with the actual capacitors. These are research leads,
  not a change to the current BOM or permission to claim PC safety.
- A USB analog switch with genuine powered-off protection can address data
  back-powering, but only with correct VBUS/logic-valid enable behavior. TI
  TS3USB221A is a candidate to evaluate, not an isolation barrier. A GPIO-only
  disconnect is insufficient if the problematic state includes reset/ROM boot.
- Full galvanic USB isolation is a separate cost/architecture decision. The
  power connection must cross the isolation barrier correctly too; isolating
  D+/D- while retaining a direct USB-ground/power path defeats that purpose.
- A TVS alone is not a sustained 55-to-5 V fault solution. A crowbar/fuse
  alternative would need explicit available-fault-current, fuse I-squared-t,
  clamp-energy and failure analysis; do not substitute it just because its
  individual parts look inexpensive.

The current LV and input-protection budget includes provisional headroom, but
does not prove these unresolved functions will fit. Report any increase in the
[overall cost dashboard](../bom/COST_DASHBOARD.md), not only in a separate note.

## Sources

- [Archived TI/ST/GCT manufacturer evidence](../../components/ti-lv-power-v2/README.md).
- [ST USBLC6-2 datasheet](https://www.st.com/resource/en/datasheet/usblc6-2.pdf),
  DS4260 Rev 7, functional diagram and layout recommendations.
- [TI TPS2660](https://www.ti.com/product/TPS2660) and
  [TPS2662 datasheet](https://www.ti.com/lit/gpn/tps2662), operating ranges and
  protection functions. Exact orderable variants are not selected.
- [TI TS3USB221A](https://www.ti.com/product/TS3USB221A), USB switch candidate.
- [Espressif ESP32-C3 technical reference manual](https://documentation.espressif.com/esp32-c3_technical_reference_manual_en.pdf),
  USB Serial/JTAG controller and PHY configuration; software is outside this session.
